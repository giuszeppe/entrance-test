<!-- Bootstrap Css -->
<link href="css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="css/icons.min.css" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="css/app.min.css" id="app-style" rel="stylesheet" type="text/css" /><?php /**PATH /home/giuseppe/Documenti/GitHub Repo/entrance-test/resources/views/partials/head-css.blade.php ENDPATH**/ ?>