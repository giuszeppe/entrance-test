<!doctype html>
<html lang="en">

<head>

    <?php echo $__env->make("partials/title-meta", ["title" => "Chat"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- glightbox css -->
    <link rel="stylesheet" href="libs/glightbox/css/glightbox.min.css">

    <!-- One of the following themes -->
    <link rel="stylesheet" href="libs/@simonwep/pickr/themes/nano.min.css" /> <!-- 'classic' theme -->

    <!-- swiper css -->
    <link rel="stylesheet" href="libs/swiper/swiper-bundle.min.css">

    <?php echo $__env->make("partials/head-css", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

<div class="layout-wrapper d-lg-flex">

    <!-- Start left sidebar-menu -->
    <?php echo $__env->make("partials/sidebar-menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end left sidebar-menu -->

    <!-- start chat-leftsidebar -->
    <?php echo $__env->make('partials/left-sidebar/left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end chat-leftsidebar -->

    <!-- Start User chat -->
    <div class="user-chat w-100 overflow-hidden">

        <div class="chat-content d-lg-flex">
            <!-- start chat conversation section -->
            <div class="w-100 overflow-hidden position-relative">
                <!-- conversation user -->
                <?php echo $__env->make("partials/conversation-user", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- conversation group -->
                <?php echo $__env->make("partials/conversation-group", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- chat input sction -->
                <?php echo $__env->make("partials/chat/chat-input", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- end chat conversation section -->

            <!-- start User profile detail sidebar -->
            <?php echo $__env->make("partials/user-profile-details", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- end User profile detail sidebar -->
        </div>
        <!-- end user chat content -->
    </div>
    <!-- End User chat -->

    <!-- Start Add contact Modal -->
    <?php echo $__env->make('modals/contacts/addContact-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Add contact Modal -->

    <!-- audiocall Modal -->
    <?php echo $__env->make('modals/audiocall-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- videocall Modal -->
    <?php echo $__env->make('modals/videocall-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- groupvideocall Modal -->
    <?php echo $__env->make('modals/groups/groupVideocall-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Start add group Modal -->
    <?php echo $__env->make('modals/groups/addGroup-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!-- Start Add pinned tab Modal -->
    <?php echo $__env->make('modals/addPinnedTab-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- forward Modal -->
    <?php echo $__env->make('modals/forward-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- contactModal -->
    <?php echo $__env->make('modals/contacts/contact-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>
<!-- end  layout wrapper -->

<?php echo $__env->make("partials/switcher", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make("partials/vendor-scripts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Modern colorpicker bundle -->
<script src="libs/@simonwep/pickr/pickr.min.js"></script>

<!-- glightbox js -->
<script src="libs/glightbox/js/glightbox.min.js"></script>

<!-- Swiper JS -->
<script src="libs/swiper/swiper-bundle.min.js"></script>

<!-- fg-emoji-picker JS -->
<script src="libs/fg-emoji-picker/fgEmojiPicker.js"></script>

<!-- page init -->
<script src="js/pages/index.init.js"></script>

</body>

</html><?php /**PATH /home/giuseppe/Documenti/GitHub Repo/entrance-test/resources/views/index.blade.php ENDPATH**/ ?>