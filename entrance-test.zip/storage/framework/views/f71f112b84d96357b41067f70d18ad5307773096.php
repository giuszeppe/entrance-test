<!-- Style switcher -->
<div id="style-switcher" style="display:none">
    <ul class="list-unstyled mb-0 vstack gap-2">
        <li>
            <a data-bs-toggle="offcanvas" href="#theme-settings-offcanvas"
                class="settings bg-soft-success text-success rounded"><i class="mdi mdi-cog mdi-spin"></i></a>
        </li>
        <li>
            <a href="javascript:void(0);" class="settings bg-soft-danger text-danger rounded"><i
                    class="ri-shopping-bag-3-line"></i></a>
        </li>
    </ul>
</div>
<!-- end switcher-->


<div class="offcanvas offcanvas-end" tabindex="-1" id="theme-settings-offcanvas"
    aria-labelledby="offcanvasExampleLabel">
    <div class="offcanvas-header bg-soft-info">
        <h5 class="offcanvas-title" id="theme-settings-offcanvasLabel">Theme Customizer</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body customizer-palettes">
        <div class="row g-3">
            <div class="col-lg-12">
                <div class="mt-3">
                    <h6 class="text-muted text-uppercase fs-13 mb-0">Select Custome Colors</h6>
                </div>
            </div>
            <div class="col-6">
                <div class="form-check card-radio">
                    <input id="customizer-color01" name="bgcolor-radio" type="radio" value="color01"
                        class="form-check-input theme-color">
                    <label class="form-check-label customizer-color01 p-0 avatar-md w-100"
                        for="customizer-color01"></label>
                </div>
                <h5 class="fs-13 text-center mt-2">Color-01</h5>
            </div>
            <div class="col-6">
                <div class="form-check card-radio">
                    <input id="customizer-color02" name="bgcolor-radio" type="radio" value="color02"
                        class="form-check-input theme-color" checked>
                    <label class="form-check-label customizer-color02 p-0 avatar-md w-100"
                        for="customizer-color02"></label>
                </div>
                <h5 class="fs-13 text-center mt-2">Color-02</h5>
            </div>
            <div class="col-6">
                <div class="form-check card-radio">
                    <input id="customizer-color03" name="bgcolor-radio" type="radio" value="color03"
                        class="form-check-input theme-color">
                    <label class="form-check-label customizer-color03 p-0 avatar-md w-100"
                        for="customizer-color03"></label>
                </div>
                <h5 class="fs-13 text-center mt-2">Color-03</h5>
            </div>
            <!-- end col -->
            <div class="col-6">
                <div class="form-check card-radio">
                    <input id="customizer-color04" name="bgcolor-radio" type="radio" value="color04"
                        class="form-check-input theme-color">
                    <label class="form-check-label customizer-color04 p-0 avatar-md w-100"
                        for="customizer-color04"></label>
                </div>
                <h5 class="fs-13 text-center mt-2">Color-04</h5>
            </div>
            <!-- end col -->
            <div class="col-6">
                <div class="form-check card-radio">
                    <input id="customizer-color05" name="bgcolor-radio" type="radio" value="color05"
                        class="form-check-input theme-color">
                    <label class="form-check-label customizer-color05 p-0 avatar-md w-100"
                        for="customizer-color05"></label>
                </div>
                <h5 class="fs-13 text-center mt-2">Color-05</h5>
            </div>
            <!-- end col -->
            <div class="col-6">
                <div class="form-check card-radio">
                    <input id="customizer-color06" name="bgcolor-radio" type="radio" value="color06"
                        class="form-check-input theme-color">
                    <label class="form-check-label customizer-color06 p-0 avatar-md w-100"
                        for="customizer-color06"></label>
                </div>
                <h5 class="fs-13 text-center mt-2">Color-06</h5>
            </div>
            <!-- end col -->
            <div class="col-6">
                <div class="form-check card-radio">
                    <input id="customizer-color07" name="bgcolor-radio" type="radio" value="color07"
                        class="form-check-input theme-color">
                    <label class="form-check-label customizer-color07 p-0 avatar-md w-100"
                        for="customizer-color07"></label>
                </div>
                <h5 class="fs-13 text-center mt-2">Color-07</h5>
            </div>
            <!-- end col -->
            <div class="col-6">
                <div class="form-check card-radio">
                    <input id="customizer-color08" name="bgcolor-radio" type="radio" value="color08"
                        class="form-check-input theme-color">
                    <label class="form-check-label customizer-color08 p-0 avatar-md w-100"
                        for="customizer-color08"></label>
                </div>
                <h5 class="fs-13 text-center mt-2">Color-08</h5>
            </div>
            <!-- end col -->
        </div>
        <!--end row-->
        <div class="row mt-4">
            <div class="col-lg-12">
                <div class="d-flex mb-3">
                    <h6 class="flex-grow-1 text-muted text-uppercase fs-13 mb-0">Select Custome Colors to Picker</h6>
                </div>
            </div>
            <!--end col-->
            <div class="col-lg-6">
                <div class="custom-colors-picker">
                    <div class="colorpicker-primary"></div>
                </div>
                <h5 class="fs-13 text-center mt-2">Primary</h5>
            </div>
            <!--end col-->
            <div class="col-lg-6">
                <div class="custom-colors-picker">
                    <div class="colorpicker-secondary"></div>
                </div>
                <h5 class="fs-13 text-center mt-2">Secondary</h5>
            </div>
            <!--end col-->
        </div>
        <!--end row-->
    </div>
</div><?php /**PATH /home/giuseppe/Documenti/GitHub Repo/entrance-test/resources/views/partials/switcher.blade.php ENDPATH**/ ?>