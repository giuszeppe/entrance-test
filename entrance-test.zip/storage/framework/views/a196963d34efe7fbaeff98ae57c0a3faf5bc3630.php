<meta charset="utf-8" />
<title><?php echo e(config('app.name', 'Laravel')); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="MwChat - Chat Application developed in Laravel with Pusher" name="description" />
<meta name="keywords" content="Chat application"/>
<meta content="social" name="author" />
<meta name="uuid" content="<?php echo e(Auth::user()->uuid ?? null); ?>">
<meta name="csrf" content="<?php echo e(csrf_token()); ?>">
<!-- App favicon -->
<link rel="shortcut icon" href="images/favicon.ico" id="tabIcon"><?php /**PATH /home/giuseppe/Documenti/GitHub Repo/entrance-test/resources/views/partials/title-meta.blade.php ENDPATH**/ ?>