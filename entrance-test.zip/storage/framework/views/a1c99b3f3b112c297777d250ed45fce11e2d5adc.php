<!doctype html>
<html lang="en">

<head>

    <?php echo $__env->make("partials/title-meta", ["title" => "Register"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make("partials/head-css", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<?php echo $__env->make("partials/body", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="auth-bg">
    <div class="container p-0">
        <div class="row justify-content-center g-0">
            <div class="col-xl-9 col-lg-8">
                <div class="authentication-page-content shadow-lg">
                    <div class="d-flex flex-column h-100 px-4 pt-4">
                        <?php echo $__env->yieldContent('content'); ?>

                        <div class="row">
                            <div class="col-xl-12">
                                <div class="text-center text-muted p-4">
                                    <p class="mb-0">&copy;
                                        <script>document.write(new Date().getFullYear())</script> <?php echo e(config('app.name')); ?>. Crafted with <i
                                            class="mdi mdi-heart text-danger"></i> by MwSpace
                                    </p>
                                </div>
                            </div><!-- end col -->
                        </div><!-- end row -->

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container-fluid -->
</div>
<!-- end auth bg -->

<?php echo $__env->make("partials/vendor-scripts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- validation init -->
<script src="js/pages/validation.init.js"></script>

<!-- theme-style init -->
<script src="js/pages/theme-style.init.js"></script>

<script src="js/app.js"></script>

</body>

</html><?php /**PATH /home/giuseppe/Documenti/GitHub Repo/entrance-test/resources/views/auth/layouts/auth.blade.php ENDPATH**/ ?>