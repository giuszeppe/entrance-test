/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
/*!*********************************************!*\
  !*** ./resources/js/dir/messageTemplate.js ***!
  \*********************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getDropdownContact": () => (/* binding */ getDropdownContact),
/* harmony export */   "getDropdownMessage": () => (/* binding */ getDropdownMessage),
/* harmony export */   "getNewMessage": () => (/* binding */ getNewMessage)
/* harmony export */ });
var getNewMessage = function getNewMessage(messageIds, content, time) {
  var position = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'left';
  return "<li class=\"chat-list ".concat(position, "\" id=\"chat-list-") + messageIds + '" >\
                <div class="conversation-list">\
                    <div class="user-chat-content">\
                        <div class="ctext-wrap">\
                            <div class="ctext-wrap-content">\
                                <p class="mb-0 ctext-content">' + content + '</p>\
                            </div>' + getDropdownMessage(messageIds) + '</div>' + '<div class="conversation-name">\
                        <small class="text-muted time">' + time + '</small>\
                        <span class="text-success check-message-icon"><i class="bx bx-check"></i></span>\
                    </div>\
                </div>\
            </div>\
        </li>';
};
var getDropdownMessage = function getDropdownMessage(messageIds) {
  return '<div class="align-self-start message-box-drop d-flex">\
  <div class="dropdown">\
      <a class="dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">\
          <i class="ri-more-2-fill"></i>\
      </a>\
      <div class="dropdown-menu">\
          <a class="dropdown-item d-flex align-items-center justify-content-between copy-message" href="#" id="copy-message-' + messageIds + '">Copy <i class="bx bx-copy text-muted ms-2"></i></a>\
          <a class="dropdown-item d-flex align-items-center justify-content-between delete-item" href="#">Delete <i class="bx bx-trash text-muted ms-2"></i></a>\
      </div>\
  </div>\
</div>';
};
var getDropdownContact = function getDropdownContact(profile, user) {
  return '<li>\
  <div class="d-flex align-items-center">\
      <div class="flex-shrink-0 me-2">\
          <div class="avatar-xs">\
          ' + profile + '\
          </div>\
      </div>\
      <div class="flex-grow-1">\
          <h5 class="fs-14 m-0" >' + user.name + '</h5>\
      </div>\
  </div>\
</li>';
};
/******/ })()
;