
import { Axios } from "axios";

export const axios = new Axios({
    withCredentials : true
})