<!-- Start chats content -->
<div>

    <div class="chat-room-list" data-simplebar>
        <!-- Start chat-message-list -->

        <div class="d-flex align-items-center px-4 mt-5 mb-2">
            <div class="flex-grow-1">
                <h4 class="mb-0 fs-11 text-muted text-uppercase">Direct Messages</h4>
            </div>
        </div>

        <div class="chat-message-list">

            <ul class="list-unstyled chat-list chat-user-list" id="usersList">
            </ul>
        </div>

        <div class="chat-message-list">

            <ul class="list-unstyled chat-list chat-user-list mb-3" id="channelList">
            </ul>
        </div>
        <!-- End chat-message-list -->
    </div>

</div>
<!-- Start chats content -->