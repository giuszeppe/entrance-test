<!-- JAVASCRIPT -->
<script src="libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="libs/simplebar/simplebar.min.js"></script>
<script src="libs/node-waves/waves.min.js"></script>